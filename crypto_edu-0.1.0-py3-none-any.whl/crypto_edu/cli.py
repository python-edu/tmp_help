from crypto_edu.myparser import args_parser

# local imports
from crypto_edu import keys
from crypto_edu import files



def main():
    """Run the command-line application."""
    args = args_parser()

    if args.command == "keygen":
    #     # Generate a private/public key pair.
    #     # Save both keys.
        private, public = keys.generate_key_pair()        
        keys.save_key_pair(args.key_name,
                           (private, public),
                           args.dir
                           )
    
    elif args.command == "encrypt":
        # Read the input file.
        # Load the public key.
        # Encrypt and save the file.
        files.encrypt_file(args.file, args.key, args.output)
         
    
    elif args.command == "decrypt":
        files.decrypt_file(args.file, args.key, args.output)
    #     # Read the encrypted file.
    #     # Load the private key.
    #     # Decrypt and save the original file.
    #     pass
    #
    else:
        print(args)
    return 0





if __name__ == '__main__':
    main()
