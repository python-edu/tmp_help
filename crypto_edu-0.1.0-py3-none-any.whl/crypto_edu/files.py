from pathlib import Path

from nacl.public import PrivateKey, PublicKey, SealedBox


def encrypt_file(input_file, public_key_file, output):
    """Encrypt a file using a public key.

    input_file: path to the original file.
    public_key_file: path to the recipient's .pub file.
    output: chosen filename; None adds .enc to the input name.
    """

    # 1. Convert input_file and public_key_file to Path objects.
    input_file = Path(input_file)
    public_key_file = Path(public_key_file)
    
    # 2. Read the original file as bytes.
    input_file_bytes = input_file.read_bytes()    
    # 3. Read the public-key bytes and create a PublicKey object.
    public_bytes = public_key_file.read_bytes()
    public_key = PublicKey(public_bytes)

    # 5. Encrypt the input using SealedBox(public_key).
    sealed_box = SealedBox(public_key)
    encrypted = sealed_box.encrypt(input_file_bytes)

    # 6. Save the encrypted bytes with output_path.open("xb").
    save_binary_file(encrypted, output)
    

def decrypt_file(input_file, private_key_file, output):
    """Decrypt a file using a private key.

    input_file: path to the encrypted file (.enc).
    private_key_file: path to the matching .key file.
    output: chosen filename; None derives a .dec filename.
    """

    # 1. Convert input_file and private_key_file to Path objects.
    input_file = Path(input_file)
    private_key_file = Path(private_key_file)
    
    # 2. Read the encrypted file as bytes.
    input_file_bytes = input_file.read_bytes()
     
    # 3. Read the private-key bytes and create a PrivateKey object.
    private_bytes = private_key_file.read_bytes()
    private_key = PrivateKey(private_bytes)
    
    # 5. Decrypt with SealedBox(private_key).
    sealed_box = SealedBox(private_key)
    decrypted = sealed_box.decrypt(input_file_bytes)
    
    # 6. Only after success, save bytes with output_path.open("xb").
    save_binary_file(decrypted, output)


def save_binary_file(data: bytes, path: str):
    path = Path(path)

    with path.open(mode='xb') as fp:
        fp.write(data)

    print(f"Saved file:\n\t{str(path)}\n")
