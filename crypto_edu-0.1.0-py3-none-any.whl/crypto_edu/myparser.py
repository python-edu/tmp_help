import argparse
from pathlib import Path


def args_parser(argv=None):
    """Create the parser and return the parsed arguments."""
    parser = argparse.ArgumentParser(prog='mycrypto',
                                     description='szyfrowanie plików')
    commands = parser.add_subparsers(dest="command", required=True)

    keygen = commands.add_parser("keygen",
                                 help="Key pair name (without extension)")
    keygen.add_argument("key_name", help="Key pair name (without extension)")
    keygen.add_argument("-d", "--dir", help="Key directory")


    encrypt = commands.add_parser("encrypt", help="Encrypt a file")
    encrypt.add_argument("file", help="File to encrypt")
    encrypt.add_argument("key", help="Public key file")
    encrypt.add_argument("-o", "--output", help="Encrypted output file")
    

    decrypt = commands.add_parser("decrypt", help="Decrypt a file")
    decrypt.add_argument("file", help="Encrypted file to decrypt")
    decrypt.add_argument("key", help="Private key file")
    decrypt.add_argument("-o", "--output", help="Decrypted output file")
    
    args = parser.parse_args(argv)
    args = valid_args(parser, args)

    return args


def valid_args(parser, args):
    
    if args.command == 'keygen':
        if args.dir is None:
            args.dir = str(Path.home()/'.crypto_edu')

    if args.command == "encrypt":
        file = Path(args.file)
        if file.suffix == ".enc":
            parser.error("Input already has .enc extension")

        if args.output is None:
            if file.suffix != '.dec':
                file = file.with_name(file.name + '.enc')

            else:
                file = file.with_suffix('.enc')

            args.output = str(file)
            
    if args.command == "decrypt":
        file = Path(args.file)
        if file.suffix == ".dec":
            parser.error("Input already has .dec extension")
        
        if args.output is None:
            if file.suffix != '.enc':
                file = file.with_name(file.name + '.dec')

            else:
                file = file.with_suffix('.dec')

            args.output = str(file)
                

    return args
