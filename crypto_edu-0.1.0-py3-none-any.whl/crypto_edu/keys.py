from pathlib import Path

from nacl.public import PrivateKey


def generate_key_pair():
    """Generate a private/public key pair; return two byte sequences."""

    # Generate a PrivateKey object.
    private_key = PrivateKey.generate()

    # Get the matching PublicKey object.
    public_key = private_key.public_key.encode()

    # Convert both objects to bytes with .encode().
    private_key = private_key.encode()
     
    # Return (private_bytes, public_bytes), in this order.
    return private_key, public_key


def check_keyfile_name(name: str) -> str:
    # Reject an empty key name.
    if not name:
        raise ValueError("Key name cannot be empty")
    
    # Keep only ASCII letters (a-z, A-Z), digits (0-9), _ and -.
    valid_name = ""
    
    for char in name:
        if (char.isascii() and char.isalnum()) or char in "_-":
            valid_name += char
    
    # Reject a name with no valid characters.
    if not valid_name:
        raise ValueError("Key name contains no valid characters")
    
    return valid_name



def save_key_pair(key_name: str,
                  keys: tuple[bytes, bytes],
                  directory: str):
    """Save the two byte sequences as files.

    key_name: base name without an extension (e.g. adam).
    keys: (private_bytes, public_bytes).
    directory: destination.
    """

    # 1. Correct key_name with check_key_name()
    key_name = check_keyfile_name(key_name)

    # 2. Convert directory to Path; create it if necessary with     
    #    mkdir(parents=True, exist_ok=True)
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    
    # 3. Build private_path (key_name.key) and public_path (key_name.pub).

    names = [f"{key_name}.{ext}" for ext in ('key', 'pub')]
    paths = [directory / name for name in names]
    
    # 4. If either file exists, raise FileExistsError.
    for pth, key in zip(paths, keys):
        if pth.exists():
            raise FileExistsError(f"File already exists: {pth}")

    # 5. Match each path to its bytes with zip() and save using "xb".
    for pth, key in zip(paths, keys):
        with pth.open(mode="xb") as file:
            file.write(key)
